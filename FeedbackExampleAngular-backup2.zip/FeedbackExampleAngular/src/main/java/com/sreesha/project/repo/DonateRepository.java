package com.sreesha.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sreesha.project.model.Donation;

public interface DonateRepository extends JpaRepository<Donation, Integer> {

}
