package com.sreesha.project.service;

import com.sreesha.project.model.Clothes;

public interface ClothesServiceInterface {

	public Integer saveClothes(Clothes clothes);
	
}
