package com.sreesha.project.service;

import com.sreesha.project.model.Volunteer;

public interface VolunteerServiceInterface {
	
	public Integer saveVolunteer(Volunteer volunteer);
	
}
