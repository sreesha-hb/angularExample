package com.sreesha.project.service;

import com.sreesha.project.model.Medical;

public interface MedicalServiceInterface {

	public Integer saveMedical(Medical medical);
	
}
