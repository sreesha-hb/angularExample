package com.sreesha.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.project.model.Medical;
import com.sreesha.project.repo.MedicalRepository;

@Service
public class MedicalServiceImpl implements MedicalServiceInterface {
	
	@Autowired
	private MedicalRepository repo;

	public Integer saveMedical(Medical medical) {
		// TODO Auto-generated method stub
		medical = repo.save(medical);
		return medical.getId();
	}

}
