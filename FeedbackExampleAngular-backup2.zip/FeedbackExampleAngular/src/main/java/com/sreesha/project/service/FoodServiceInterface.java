package com.sreesha.project.service;

import com.sreesha.project.model.Food;

public interface FoodServiceInterface {
	public Integer saveFood(Food food);
}
