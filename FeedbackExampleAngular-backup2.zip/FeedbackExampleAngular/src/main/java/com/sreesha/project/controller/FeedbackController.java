package com.sreesha.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sreesha.project.model.Clothes;
import com.sreesha.project.model.Donation;
import com.sreesha.project.model.FeedbackModel;
import com.sreesha.project.model.Food;
import com.sreesha.project.model.Medical;
import com.sreesha.project.model.Travel;
import com.sreesha.project.model.User;
import com.sreesha.project.model.Volunteer;
import com.sreesha.project.service.ClothesServiceInterface;
import com.sreesha.project.service.DonationServiceInterface;
import com.sreesha.project.service.FeedbackServiceInterface;
import com.sreesha.project.service.FoodServiceInterface;
import com.sreesha.project.service.MedicalServiceInterface;
import com.sreesha.project.service.TravelServiceInterface;
import com.sreesha.project.service.UserServiceInterface;
import com.sreesha.project.service.VolunteerServiceInterface;

@RestController
@RequestMapping("/rest/feedback")
@CrossOrigin(origins = "http://localhost:4200")
public class FeedbackController {
	
	@Autowired
	private FeedbackServiceInterface fsi;
	
	@Autowired
	private VolunteerServiceInterface vsi;
	
	@Autowired
	private UserServiceInterface usi;
	
	@Autowired
	private FoodServiceInterface foodsi;
	
	@Autowired
	private ClothesServiceInterface csi;
	
	@Autowired
	private MedicalServiceInterface msi;
	
	@Autowired
	private TravelServiceInterface tsi;
	
	@Autowired
	private DonationServiceInterface dsi;
	
	@PostMapping("/add")
	public ResponseEntity<String> saveFeedback(@RequestBody FeedbackModel feedback) {
		try {
			Integer id = fsi.saveFeedback(feedback);
			String msg = "Feedback with id "+id+" created successfully";
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			return new ResponseEntity<String>("Unable to create feedback", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/volunteer")
	public ResponseEntity<String> saveVolunteer(@RequestBody Volunteer volunteer) {
		try {
			Integer id = vsi.saveVolunteer(volunteer);
			String msg = "Thank you for Signing up as a Volunteer. Your volunteer account has been created with id "+id+".";
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<String>("Unable to create volunteer", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/reg")
	public ResponseEntity<String> saveUser(@RequestBody User user) {
		try {
			String mail = usi.saveUser(user);
			String msg = "Registration Successful with the mail address "+mail+".";
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<String>("Unable to create", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/food")
	public ResponseEntity<String> saveFood(@RequestBody Food food) {
		try {
			Integer id = foodsi.saveFood(food);
			String msg = "Request for food submitted sucessfully! Your request id is "+id;
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			return new ResponseEntity<String>("Unable to create!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@PostMapping("/cloth")
	public ResponseEntity<String> saveclothes(@RequestBody Clothes clothes){
		try {
			int id = csi.saveClothes(clothes);
			String msg = "Request for clothes submitted sucessfully! Your request id is "+id;
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Unable to create!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@PostMapping("/medical")
	public ResponseEntity<String> saveMedical(@RequestBody Medical medical) {
		try {
			Integer id = msi.saveMedical(medical);
			String msg = "Request for medicine submitted sucessfully! Your request id is "+id;
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Unable to create!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@PostMapping("/travel")
	public ResponseEntity<String> saveTravel(@RequestBody Travel travel) {
		try {
			String email = tsi.saveTravel(travel);
			String msg = "Request for travel submitted sucessfully reference to mail: "+email;
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Unable to create!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@PostMapping("/donation")
	public ResponseEntity<String> saveDonation(@RequestBody Donation donation) {
		try {
			Integer id = dsi.saveDonation(donation);
			String msg = "Thank you for your contribution! Your reference id is "+id;
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Unable to create!", HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}
	
}
