package com.sreesha.project.service;

import com.sreesha.project.model.FeedbackModel;

public interface FeedbackServiceInterface {
	
	public Integer saveFeedback(FeedbackModel fb);
	
}	
