package com.sreesha.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.project.model.Food;
import com.sreesha.project.repo.FoodRepository;

@Service
public class FoodServiceImpl implements FoodServiceInterface {

	@Autowired
	private FoodRepository repo;
	
	public Integer saveFood(Food food) {
		// TODO Auto-generated method stub
		food = repo.save(food);
		return food.getId();
	}
	
}
