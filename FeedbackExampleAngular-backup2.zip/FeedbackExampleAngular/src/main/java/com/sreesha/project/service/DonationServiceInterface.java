package com.sreesha.project.service;

import com.sreesha.project.model.Donation;

public interface DonationServiceInterface {

	public Integer saveDonation(Donation donation);
}
