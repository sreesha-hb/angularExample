package com.sreesha.in.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sreesha.in.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}
