package com.sreesha.in.service;

import java.util.List;

import com.sreesha.in.model.Employee;

public interface ServiceInterface {
	
	public Integer saveEmployee(Employee employee);
	
	public List<Employee> getAllEmp();
	
	public void deleteEmp(Integer id);

}
