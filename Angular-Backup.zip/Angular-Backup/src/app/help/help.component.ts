import { Component, OnInit } from '@angular/core';
import { FeedbackServices } from './../feedback.service';
import { Food } from './../food';
import { Clothes } from './../clothes';
import { Medical } from './../medical';
import { Travel } from './../travel';
import { Donation } from './../donation';
import {MatSnackBar} from '@angular/material/snack-bar';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.css']
})
export class HelpComponent implements OnInit {

  food!: Food;
  clothes!: Clothes;
  medical!: Medical;
  travel!: Travel;
  donate!: Donation;
  message!: string;

  constructor(private service: FeedbackServices, private sb: MatSnackBar) { }

  ngOnInit(): void {
    this.food = new Food();
    this.clothes = new Clothes();
    this.medical = new Medical();
    this.travel = new Travel();
    this.donate = new Donation();
  }

  foodReq() {
    this.service.foodReq(this.food).subscribe(
      data => {this.food = new Food(); this.message = data; this.sb.open(data.toString(), "OKAY")}, error => {console.log(error)}
    );
  }

  clothReq() {
    this.service.clothReq(this.clothes).subscribe(
      data => {this.clothes = new Clothes(); this.message = data; this.sb.open(data.toString(), "OKAY")}, error => {console.log(error)}
    );
  }

  mediReq() {
    this.service.mediReq(this.medical).subscribe(
      data => {this.medical = new Medical(); this.message = data; this.sb.open(data.toString(), "OKAY")}, error => {console.log(error)}
    );
  }

  travReq() {
    this.service.travReq(this.travel).subscribe(
      data => {this.travel = new Travel(); this.message = data; this.sb.open(data.toString(), "OKAY")}, error => {console.log(error)}
    );
  }

  donation() {
    this.service.donation(this.donate).subscribe(
      data => {this.donate = new Donation(); this.message = data; this.sb.open(data.toString(), "OKAY")}, error => {console.log(error)}
    );
  }

}
