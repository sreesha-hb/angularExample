export class Clothes {
   email!: string;
   name!: string;
   address!: string;
   numberofpeople!: number;
   description!: string;
}