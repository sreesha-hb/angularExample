export class Medical {
   cemail!: string;
   caddress!: string;
   medicine!: string;
}