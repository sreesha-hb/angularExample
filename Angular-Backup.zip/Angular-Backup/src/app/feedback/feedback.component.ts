import { Component, OnInit } from '@angular/core';
import { FeedbackServices } from './../feedback.service';
import { Feedback } from './../feedback';
import {MatSnackBar} from '@angular/material/snack-bar';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  feedback!: Feedback;
  message!: string;
  

  constructor(private service: FeedbackServices, private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.feedback = new Feedback();
  }

  createFb() {
    this.service.createFb(this.feedback).subscribe(
      data => {this.feedback = new Feedback(); this.message = data; this._snackBar.open(data.toString(), "Okay")}, error => {console.log(error)}
    );
  }

}
