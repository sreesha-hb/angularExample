export class Travel {
   email!: string;
   name!: string;
   paddress!: string;
   daddress!: string;
}