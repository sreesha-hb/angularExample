import { Component, OnInit } from '@angular/core';
import { FeedbackServices } from './../feedback.service';
import { User } from './../user'; 
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-help-login',
  templateUrl: './help-login.component.html',
  styleUrls: ['./help-login.component.css']
})
export class HelpLoginComponent implements OnInit {

  user!: User;
  message!: string;

  constructor(private service: FeedbackServices, private sb: MatSnackBar) { }

  ngOnInit(): void {
    this.user = new User();
  }

  regUser() {
    this.service.regUser(this.user).subscribe(
      data => {this.user = new User(); this.message = data; this.sb.open(data.toString(), "Dismiss");}, error => {console.log(error)}
    );
  }
 
}
