import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FeedbackComponent } from './feedback/feedback.component';
import { HomeComponent } from './home/home.component';
import { VolunteerComponent } from './volunteer/volunteer.component';
import { HelpLoginComponent } from './help-login/help-login.component';
import { HelpComponent } from './help/help.component';

const routes: Routes = [
  {path: 'home', component: HomeComponent },
  {path: 'feedback', component: FeedbackComponent },
  {path: 'volunteer', component: VolunteerComponent },
  {path: 'help-login', component: HelpLoginComponent },
  {path: 'help', component: HelpComponent },
  {path: '', redirectTo: 'home', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
