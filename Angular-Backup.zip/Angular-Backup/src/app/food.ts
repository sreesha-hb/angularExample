export class Food {
   name!: string;
   email!: string;
   address!: string;
   Nop!: string;
}