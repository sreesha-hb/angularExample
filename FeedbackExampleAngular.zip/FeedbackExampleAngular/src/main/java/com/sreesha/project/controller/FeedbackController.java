package com.sreesha.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sreesha.project.model.FeedbackModel;
import com.sreesha.project.model.User;
import com.sreesha.project.model.Volunteer;
import com.sreesha.project.service.FeedbackServiceInterface;
import com.sreesha.project.service.UserServiceInterface;
import com.sreesha.project.service.VolunteerServiceInterface;

@RestController
@RequestMapping("/rest/feedback")
@CrossOrigin(origins = "http://localhost:4200")
public class FeedbackController {
	
	@Autowired
	private FeedbackServiceInterface fsi;
	
	@Autowired
	private VolunteerServiceInterface vsi;
	
	@Autowired
	private UserServiceInterface usi;
	
	@PostMapping("/add")
	public ResponseEntity<String> saveFeedback(@RequestBody FeedbackModel feedback) {
		try {
			Integer id = fsi.saveFeedback(feedback);
			String msg = "Feedback with id "+id+" created successfully";
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			return new ResponseEntity<String>("Unable to create feedback", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/volunteer")
	public ResponseEntity<String> saveVolunteer(@RequestBody Volunteer volunteer) {
		try {
			Integer id = vsi.saveVolunteer(volunteer);
			String msg = "Thank you for Signing up as a Volunteer. Your volunteer account has been created with id "+id+".";
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<String>("Unable to create volunteer", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/reg")
	public ResponseEntity<String> saveUser(@RequestBody User user) {
		try {
			String mail = usi.saveUser(user);
			String msg = "Registration Successful with the mail address "+mail+".";
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<String>("Unable to create", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
