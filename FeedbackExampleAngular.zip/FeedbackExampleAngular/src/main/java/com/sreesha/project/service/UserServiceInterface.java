package com.sreesha.project.service;

import com.sreesha.project.model.User;

public interface UserServiceInterface {

	public String saveUser(User user);
}
